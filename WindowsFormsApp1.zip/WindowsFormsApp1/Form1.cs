﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        List<Pechka> pechkas = new List<Pechka>();
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            //try
            //{
                if (!string.IsNullOrEmpty(textBox1.Text) &&
                !string.IsNullOrEmpty(textBox2.Text) &&
                !string.IsNullOrEmpty(textBox3.Text) &&
                !string.IsNullOrEmpty(textBox4.Text))
                {
                    Pechka pech = new Pechka(int.Parse(textBox1.Text), double.Parse(textBox2.Text), textBox3.Text, double.Parse(textBox4.Text));
                    pechkas.Add(pech);
                    listBox1.Items.Add($"Печь В-100");
                    listBox1.Items.Add($"Номер производителя {pech.NumOfCreator}");
                    listBox1.Items.Add($"Напряжение постоянного тока {pech.W}");
                    listBox1.Items.Add($"Интерфейс входа {pech.interfaceIn}");
                    listBox1.Items.Add($"Потребляемая мощность {pech.WT}");


            }
                else
                {
                    MessageBox.Show("Вы не заполнили поля");
                }
            //}
            //catch
            //{
            //    MessageBox.Show("Ошибка ввода данных в полях");
            //}
        }
    }
}
