﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WindowsFormsApp1
{
    internal class Pechka
    {
        public int NumOfCreator { get { return numOfCreator; } set { numOfCreator = value; } }

        private int numOfCreator;
        public double W;
        public string interfaceIn;
        public double WT;

        public Pechka(int numOfCreator, double w, string inter, double wt)
        {
            this.NumOfCreator = numOfCreator;
            this.W = w;
            this.interfaceIn = inter;
            this.WT = wt;
        }
    }
}
